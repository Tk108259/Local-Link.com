# Code Citations

## License: unknown
https://github.com/Cyprian6Richard/confiar/tree/c5429618e899a5dc7aaf75666cefbb619aeca595/forms/professionalindemnity.html

```
>
  <div class="form-group">
    <label for="businessName">Business Name</label>
    <input type="text" id="businessName" name="businessName" required>
  </div>
  <div class="form-
```


## License: unknown
https://github.com/alstendsouza/phonebook/tree/8e1dbce89ff6ce07e68b0893c6df1a74b40c42b6/index.php

```
</div>
  <div class="form-group">
    <label for="phone">Phone Number</label>
    <input type="text" id="phone" name="phone" required>
  </div>
  <div class=
```

